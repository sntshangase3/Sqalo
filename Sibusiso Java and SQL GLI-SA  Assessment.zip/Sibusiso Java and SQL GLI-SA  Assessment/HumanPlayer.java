/**
 * HumanPlayer
 */


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

import java.util.logging.Logger;

public class HumanPlayer implements Player
{
  private static Logger logger_
    = Logger.getLogger(HumanPlayer.class.getName());

  private String name_ = "HumanPlayer";

  /**
   * The default constructor for the HumanPlayer class.
   */
  public HumanPlayer()
    {
    }


  /**
   * The name of the player.  This method is inherited from Player.
   */
  public String name() { return name_; }


  /**
   * Get the human player's next letter.  This method is inherited from Player 
     * @param wordInPlay The word currently being played.
   */
  public char play(String wordInPlay)
    {
    if (wordInPlay.length() == 0)
      System.out.print("Pick your first letter:  ");
    else
      System.out.print("Pick your next letter:  " + wordInPlay);

    char letter = '\0';
    try
      {
      BufferedReader reader
        = new BufferedReader(new InputStreamReader(System.in));
      letter = (char)reader.read();
      }
    catch (IOException e)
      {
      logger_.severe("Error reading from System.in:  " + e.toString());
      }

    return letter;
    }
} 
