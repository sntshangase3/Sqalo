/**
 * Player declares the methods that must be implemented by
 * Game players.
 */


public interface Player
{
  /**
   * The name of the player.
   */
  public String name();


  /**
   * Add a character to the word in play.
   *
   * @param wordInPlay The word currently being played.
   */
  public char play(String wordInPlay);
}  
