/**
 * Dictionary maintains a list of words for playing Game.
 */

import java.util.HashMap;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.logging.Logger;

public class Dictionary
{
  private static final int MIN_WORD_LENGTH = 4;

  private static Logger logger_
    = Logger.getLogger(Dictionary.class.getName());

  private HashMap<Character,LetterNode> words_
    = new HashMap<Character,LetterNode>();

  /**
   * Add a word to the dictionary :
   * @param word The word to add to the dictionary.
   */
  private void addWord(String word)
    {
    if (word.length() >= MIN_WORD_LENGTH)
      {
      LetterNode node = words_.get(Character.valueOf(word.charAt(0)));

      if (node == null)
        words_.put(Character.valueOf(word.charAt(0)),new LetterNode(word));
      else
        node.addWord(word);
      }
    }


  /**
   * The file constructor for the Dictionary class.
   *
   * @param fileName The name of the dictionary sorted file. 
   */
  public Dictionary(String fileName)
    {
    try
      {
      BufferedReader reader = new BufferedReader(new FileReader(fileName));
      String word = null;
      while ((word = reader.readLine()) != null)
        addWord(word);
      }
    catch (FileNotFoundException fileNotFoundException)
      {
      logger_.severe("File " + fileName + " not found.");
      }
    catch (IOException ioException)
      {
      logger_.severe("Error reading file:  " + ioException.toString());
      }
    }


  /**
   * Return the number of words in the dictionary.
   */
  public int size()
    {
    int count = 0;

    for (LetterNode node : words_.values())
      count += node.leafNodeCount();

    return count;
    }


  /**
   * Return the length of the longest string in the dictionary.
   */
  public int maximumLength()
    {
    int length = 0;
    int maximumLength = 0;

    for (LetterNode node : words_.values())
      {
      length = node.maximumLength();
      if (length > maximumLength)
        maximumLength = length;
      }

    return maximumLength;
    }


  /**
   * Find the node matching the string.
    * @param string to look for.
   */
  public LetterNode terminalNode(String string)
    {
    LetterNode startNode = words_.get(Character.valueOf(string.charAt(0)));
    LetterNode node = startNode;

    if (startNode != null)
      for (int i = 1;i < string.length();i++)
        {
        node = node.child(string.charAt(i));
        if (node == null)
          break;
        }

    return node;
    }


  /**
   * Determine if the word is in the dictionary.
   *
   * @param word to look for.
   */
  public boolean isFullWord(String word)
    {
    boolean isFullWord = false;

    LetterNode node = terminalNode(word);
    if ((node != null) && (node.isLeafNode()))
      isFullWord = true;

    return isFullWord;
    }


  /**
   * Determine if the string is the start of a word in the dictionary.
   *
   * @param stem  to look for.
   */
  public boolean isWordStem(String stem)
    {
    boolean isWordStem = false;

    LetterNode node = terminalNode(stem);
    if (node != null)
      isWordStem = true;

    return isWordStem;
    }


  /**
     * @param args arguments passed in.
   */
  public static void main(String args[])
    {
    if (args.length == 1)
      {
      Dictionary dictionary = new Dictionary(args[0]);

      logger_.info("Created dictionary with "
                   + dictionary.size()
                   + " words, the longest having "
                   + dictionary.maximumLength()
                   + " letters.");
      }
   
    }
} 
