/**
 * Game is the main class for playing game.
 * In the game, two players take turns building up a word from
 * left to right.  Each player contributes one letter per turn. The goal
 * is to not complete the spelling of a word:  if you add a letter that
 * completes a word (of 4+ letters), or if you add a letter that
 * produces a string that cannot be extended into a word, you lose.
 */



import java.util.logging.Logger;

public class Game
{
  private static Logger logger_ = Logger.getLogger(Game.class.getName());

  private Dictionary dictionary_ = null;
  private Player[] players_ = new Player[2];;
  private int currentPlayerIndex_ = 0;
  private StringBuffer wordInPlay_ = new StringBuffer();
  private boolean gameOver_ = false;
  private Player winner_ = null;

  /**
   * The full constructor for the Game class.
   *
   * @param fileName The name of the dictionary file.
   * @param playerOne A reference to the first player.
   * @param playerTwo A reference to the computer player.
   */
  public Game(String fileName,Player playerOne,Player playerTwo)
    {
    dictionary_ = new Dictionary(fileName);
    if (dictionary_.size() == 0)
      throw new RuntimeException("Unable to load dictionary from "
                                 + fileName
                                 + ".");

    players_[0] = playerOne;
    players_[1] = playerTwo;
    }


  /**
   * Switch the current player.
   *
   * @return The updated current player index.
   */
  private int switchPlayer()
    {
    return (currentPlayerIndex_ = ++currentPlayerIndex_ % 2);
    }


  /**
   * Add a letter to the word in play.
   */
  private void addLetter(char letter)
    {
    wordInPlay_.append(letter);

    if (dictionary_.isFullWord(wordInPlay_.toString())
        || !dictionary_.isWordStem(wordInPlay_.toString()))
      {
      gameOver_ = true;
      winner_ = players_[switchPlayer()];
      }
    }


  /**
   * Play the game.
   *
   * @return The winning player.
   */
  public Player play()
    {
    while (!gameOver_)
      {
      addLetter(players_[currentPlayerIndex_].play(wordInPlay_.toString()));
      switchPlayer();
      }

    return winner_;
    }


  /**
   * Return the word in play.
   */
  public String wordInPlay() { return wordInPlay_.toString(); }


  /**
    * @param args The command line arguments passed in.
   */
  public static void main(String args[])
    {
    if (args.length == 3)
      {
      Game game = null;
      try
        {
        Player playerOne
          = (Player)Class.forName(args[1]).newInstance();
        Player playerTwo
          = (Player)Class.forName(args[2]).newInstance();

        game = new Game(args[0],playerOne,playerTwo);
        }
      catch (Exception e)
        {
        logger_.severe("Unable to initialize Game:  " + e.toString());
        }

      Player winner = game.play();

      logger_.info("Final word:  " + game.wordInPlay() + ", "
                   + winner.name() + " wins!");
      }
    else
      logger_.info("Usage:  java "
                   + Game.class.getName()
                   + " <word-list> <player-one> <player-two>");
    }
}  
