/**
 * PCPlayer
 */


import java.util.Collection;
import java.util.Iterator;

import java.util.logging.Logger;

public class PCPlayer implements Player
{
  private static final String DEFAULT_DICTIONARY_FILE = "WORD.LST";

  private static Logger logger_
    = Logger.getLogger(PCPlayer.class.getName());

  private String name_ = "PCPlayer";
  private Dictionary dictionary_
    = new Dictionary(DEFAULT_DICTIONARY_FILE);

  /**
   * The default constructor for the PCPlayer class.
   */
  public PCPlayer()
    {
    }


  /**
   * The name of the player.  This method is inherited from Player.
   */
  public String name() { return name_; }


  /**
   * Find a forced win, if available.  A forced win occurs from a particular node 
   * @param node The node from which to find a forced win.
   */
  public LetterNode forcedWin(LetterNode node)
    {
    LetterNode winningChild = null;

    for (LetterNode child : node.children().values())
      {
      if (!child.isLeafNode())
        {
        winningChild = child;
        for (LetterNode grandChild : child.children().values())
          if (!(grandChild.isLeafNode() || (forcedWin(grandChild) != null)))
            {
            winningChild = null;
            break;
            }
        }

      if (winningChild != null)
        break;
      }

    return winningChild;
    }


  /**
   * Find the longest word from node.
    * @param node which to find the longest word.
   */
  public LetterNode longestWord(LetterNode node)
    {
    LetterNode longestChild = null;

    for (LetterNode child : node.children().values())
      if ((longestChild == null)
          || (child.maximumLength() > longestChild.maximumLength()))
        longestChild = child;

    return longestChild;
    }


  /**
   * Get the player's next letter.  This method is inherited from Player.
   * @param wordInPlay The word currently being played.
   */
  public char play(String wordInPlay)
    {
    char nextLetter = 'x';

    LetterNode node = dictionary_.terminalNode(wordInPlay);
    if (node != null)
      {
      LetterNode forcedWin = forcedWin(node);
      if (forcedWin != null)
        nextLetter = forcedWin.letter();
      else
        nextLetter = longestWord(node).letter();
      }

    return nextLetter;
    }
}  
