/**
 * LetterNode is a class that control a tree of letters making up words
 */


import java.util.HashMap;

import java.lang.IllegalArgumentException;

import java.util.logging.Logger;

public class LetterNode
{
  private static Logger logger_ = Logger.getLogger(LetterNode.class.getName());

  private char letter_;
  private HashMap<Character,LetterNode> nodes_
    = new HashMap<Character,LetterNode>();

  /**
   * The constructor for LetterNode.
   *
   * @param word The word, or substring, to add to this node.
   */
  public LetterNode(String word)
    {
    if (word.length() > 0)
      letter_ = word.charAt(0);

    if (word.length() > 1)
      nodes_.put(Character.valueOf(word.charAt(1)),
                 new LetterNode(word.substring(1)));
    }


  /**
   * Add word to the tree rooted to node.
   *
   * @param word  to add to node.
   */
  public void addWord(String word) throws IllegalArgumentException
    {
    if (word.charAt(0) == letter_)
      {
      if (!nodes_.isEmpty())
        {
        if (word.length() == 1)
          nodes_.clear();
        else
          {
          LetterNode nextNode = nodes_.get(Character.valueOf(word.charAt(1)));

          if (nextNode == null)
            nodes_.put(Character.valueOf(word.charAt(1)),
                       new LetterNode(word.substring(1)));
          else
            nextNode.addWord(word.substring(1));
          }
        }
      }
    else
      throw new IllegalArgumentException("Invalid first letter.");
    }


  /**
   * Find maximum length of a word.
   */
  public int maximumLength()
    {
    int length = 0;
    int maximumLength = 0;

    for (LetterNode node : nodes_.values())
      {
      length = node.maximumLength();
      if (length > maximumLength)
        maximumLength = length;
      }

    return maximumLength + 1;
    }


  /**
   * Determine leaf.
   */
  public boolean isLeafNode()
    {
    return nodes_.isEmpty();
    }


  /**
   * Find the number of leaf.
   */
  public int leafNodeCount()
    {
    int leaves = 0;

    if (isLeafNode())
      leaves = 1;
    else
      for (LetterNode node : nodes_.values())
        leaves += node.leafNodeCount();

    return leaves;
    }


  /**
   * Return the child node.
   *
   * @param letter character of the child.
   */
  public LetterNode child(char letter)
    {
    return nodes_.get(Character.valueOf(letter));
    }


  /**
   * Letter.
   */
  public char letter() { return letter_; }


  /**
   * Child.
   */
  public HashMap<Character,LetterNode> children() { return nodes_; }


  /**
     * @param compare for equality.
   */
  public boolean equals(Object object)
    {
    return (object == this)
           || ((object != null)
               && (object instanceof LetterNode)
               && (letter_ == ((LetterNode)object).letter_));
    }


  /**
   * @return The hashcode for the LetterNode class.
   */
  public int hashCode()
    {
    int result = 17;

    result = 37 * result + (int)letter_;

    return result;
    }


  /**
     * @param args arguments passed in.
   */
  public static void main(String args[])
    {
    if (args.length > 0)
      {
      LetterNode node = new LetterNode(args[0]);

      for (int i = 1;i < args.length;i++)
        node.addWord(args[i]);

      logger_.info("Total words = " + node.leafNodeCount());
      logger_.info("Maximum word length = " + node.maximumLength());
      }
 
    }
} 
