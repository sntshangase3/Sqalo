/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sibusisoinclusivepokersecondsolution;

import java.util.Arrays;

/**
 *
 * @author sibusiso
 */
public class Score {
       final int weight;
        final String name;
        final String[] hand;
 
        Score(String n, int w, String[] h) {
            weight = w;
            name = n;
            hand = h != null ? h.clone() : h;
        }
 
        @Override
        public String toString() {
            return Arrays.toString(hand) + " " + name;
        }
}
